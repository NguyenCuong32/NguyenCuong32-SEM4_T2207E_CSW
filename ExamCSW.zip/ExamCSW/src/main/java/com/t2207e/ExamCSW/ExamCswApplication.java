package com.t2207e.ExamCSW;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExamCswApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExamCswApplication.class, args);
	}

}
