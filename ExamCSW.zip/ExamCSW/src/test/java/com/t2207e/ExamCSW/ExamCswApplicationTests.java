package com.t2207e.ExamCSW;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamCswApplicationTests {

	@Test
	void contextLoads() {
	}

}
